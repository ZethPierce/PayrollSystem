﻿Imports System.Data.OleDb

Public Class Form6
    'ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\marc\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\user\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    Dim conn As OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
    Private Sub Form6_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Load_Employees()

    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

   
    Private Sub Load_Employees()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New OleDbDataAdapter("Select * from tbl_employee", conn)
        da.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim index As Integer
        index = e.RowIndex
        Dim selectedrow As DataGridViewRow
        selectedrow = DataGridView1.Rows(index)
        TextBox1.Text = selectedrow.Cells(1).Value.ToString()
        TextBox2.Text = selectedrow.Cells(2).Value.ToString()
        TextBox3.Text = selectedrow.Cells(3).Value.ToString()
        TextBox4.Text = selectedrow.Cells(4).Value.ToString()

    End Sub

   
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Try
            Add_Employee()

            MessageBox.Show("Your Total Salary is: " + TextBox8.Text)
        Catch ex As Exception
            MessageBox.Show("Failed")
        End Try

        
    End Sub


    Private Sub Add_Employee()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        TextBox8.Text = Val(TextBox5.Text) * Val(TextBox6.Text - TextBox7.Text)
        conn.Open()
        Dim cmdinsert As New OleDbCommand("INSERT INTO tbl_employeewage (enum, lname, fname, mname, hourlyrate, presentdays, absences, netpay) VALUES (@enum, @lname, @fname, @mname, @hourlyrate, @presentdays, @absences, @netpay)", conn)
        cmdinsert.Parameters.AddWithValue("@enum", TextBox1.Text)
        cmdinsert.Parameters.AddWithValue("@lname", TextBox2.Text)
        cmdinsert.Parameters.AddWithValue("@fname", TextBox3.Text)
        cmdinsert.Parameters.AddWithValue("@mname", TextBox4.Text)
        cmdinsert.Parameters.AddWithValue("@hourlyrate", TextBox5.Text)
        cmdinsert.Parameters.AddWithValue("@presentdays", TextBox6.Text)
        cmdinsert.Parameters.AddWithValue("@absences", TextBox7.Text)
        cmdinsert.Parameters.AddWithValue("@netpay", TextBox8.Text)



        cmdinsert.ExecuteNonQuery()
        conn.Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        MainMenu.Show()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Hide()
        Form7.show()
    End Sub
End Class