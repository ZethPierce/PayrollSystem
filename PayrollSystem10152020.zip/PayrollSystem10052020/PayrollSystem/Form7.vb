﻿Imports System.Data.OleDb

Public Class Form7
    'ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\marc\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\user\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    Dim conn As OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
    Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Load_Salary()
    End Sub

    Private Sub Load_Salary()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New OleDbDataAdapter("Select * from tbl_employeewage", conn)
        da.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form6.Show()
    End Sub
End Class