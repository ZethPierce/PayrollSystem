﻿Imports System.Data.OleDb
Public Class Form2
    Dim conn As New OleDb.OleDbConnection("Provider=microsoft.Jet.oledb.4.0; Data Source=" & Application.StartupPath.ToString & "\payroll.accdb")
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
   
    Dim myConnection As OleDbConnection = New OleDbConnection


    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim conn As New OleDbConnection
        Try
            conn.Open()
            MessageBox.Show("Working")
            conn.Close()
        Catch ex As Exception
            MessageBox.Show("Not Working")
            conn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If TextBox1.Text = "" And TextBox2.Text = "" And TextBox3.Text = "" And TextBox4.Text = "" And TextBox5.Text = "" And TextBox6.Text = "" And TextBox7.Text = "" Then
            MessageBox.Show("You need to fill up all forms.")
        Else
            MessageBox.Show("Employee Added!")
            Button2.Enabled = True
        End If

    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form3.Show()
    End Sub



    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Form3.Show()
    End Sub
End Class