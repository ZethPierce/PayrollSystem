﻿Imports System.Data.OleDb

Public Class Form3
    'ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\marc\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\user\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    Dim conn As OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Load_Dependents()
        Load_All_Employee_ID()

    End Sub

    Private Sub Load_All_Employee_ID() 'To load employee ID number in Textbox1 from tbl_employee
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New OleDbDataAdapter("Select * from tbl_employee", conn)
        da.Fill(table)
        ComboBox1.DataSource = table
        ComboBox1.DisplayMember = "enum"
        ComboBox1.ValueMember = "enum"
    End Sub

    Private Sub Load_Dependents()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New OleDbDataAdapter("Select * from tbl_dependent", conn)
        da.Fill(table)
        DataGridView1.DataSource = table
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Add_Dependent()
            MessageBox.Show("Added Success")
            Load_Dependents()
        Catch ex As Exception
            MessageBox.Show("Not Success")
        End Try

    End Sub

    Private Sub Add_Dependent()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        Dim cmdinsert As New OleDbCommand("INSERT INTO tbl_dependent (enum, dname, bdate, relation) VALUES (@enum, @dname, @bdate, @relation)", conn)
        cmdinsert.Parameters.AddWithValue("@enum", ComboBox1.Text)
        cmdinsert.Parameters.AddWithValue("@dname", TextBox2.Text)
        cmdinsert.Parameters.AddWithValue("@bdate", TextBox3.Text)
        cmdinsert.Parameters.AddWithValue("@relation", TextBox4.Text)
        cmdinsert.ExecuteNonQuery()
        conn.Close()
    End Sub


    Private Sub AddEmployeeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub ManageDepartmentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form4.Show()
    End Sub

    Private Sub ManageDeductionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Form4.Show()
    End Sub


End Class