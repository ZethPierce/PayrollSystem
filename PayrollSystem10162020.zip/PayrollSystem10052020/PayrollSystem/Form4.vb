﻿Imports System.Data.OleDb

Public Class Form4
    'ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\marc\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    ReadOnly CONNECTION_STRING As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\user\Documents\Visual Studio 2010\Projects\PayrollSystem10052020\PayrollSystem\bin\Debug\payroll_db.accdb"
    Dim conn As OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Add_Dept()
            MessageBox.Show("Added Success")
            Load_Dept()
        Catch ex As Exception
            MessageBox.Show("Not Success")
        End Try
    End Sub

    Private Sub Add_Dept()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        Dim cmdinsert As New OleDbCommand("INSERT INTO tbl_department (deptnum, dname, telnum) VALUES (@deptnum, @dname, @telnum,)", conn)
        cmdinsert.Parameters.AddWithValue("@enum", TextBox1.Text)
        cmdinsert.Parameters.AddWithValue("@dname", TextBox2.Text)
        cmdinsert.Parameters.AddWithValue("@bdate", TextBox3.Text)
        cmdinsert.ExecuteNonQuery()
        conn.Close()
    End Sub

    Private Sub Load_Dept()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New OleDbDataAdapter("Select * from tbl_department", conn)
        da.Fill(table)
        DataGridView1.DataSource = table
    End Sub

    Private Sub AddEmployeeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub ManageDepartmentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Show()
        Me.Hide()
    End Sub

    Private Sub ManageDeductionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Load_Dept()
    End Sub
End Class